
import { GoogleGenAI } from "@google/genai";

class TarotVisionAI {
    constructor() {
        // State
        this.imageData = null;
        this.stream = null;

        // DOM Elements
        this.video = document.getElementById('video');
        this.canvas = document.getElementById('canvas');
        this.imagePreview = document.getElementById('image-preview');
        this.uploadPlaceholder = document.getElementById('upload-placeholder');
        
        this.captureBtn = document.getElementById('capture-btn');
        this.uploadBtn = document.getElementById('upload-btn');
        this.uploadInput = document.getElementById('upload-input');
        this.analyzeBtn = document.getElementById('analyze-btn');
        this.resetBtn = document.getElementById('reset-btn');

        this.resultContainer = document.getElementById('result');
        this.loader = document.getElementById('loading-spinner');

        // AI Model
        this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        this.model = 'gemini-2.5-flash-image';

        this.init();
    }

    init() {
        this.addEventListeners();
    }

    addEventListeners() {
        this.captureBtn.addEventListener('click', () => this.handleCamera());
        this.uploadBtn.addEventListener('click', () => this.uploadInput.click());
        this.uploadInput.addEventListener('change', (e) => this.handleFileUpload(e));
        this.analyzeBtn.addEventListener('click', () => this.analyzeImage());
        this.resetBtn.addEventListener('click', () => this.reset());
    }
    
    async handleCamera() {
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
            this.video.srcObject = this.stream;
            this.video.classList.remove('hidden');
            this.uploadPlaceholder.classList.add('hidden');
            this.imagePreview.classList.add('hidden');
            
            // Change button to "Take Photo"
            this.captureBtn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M20 4h-3.17L15 2H9L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h4.05l1.83-2h4.24l1.83 2H20v12zM12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0 8c-1.65 0-3-1.35-3-3s1.35-3 3-3 3 1.35 3 3-1.35 3-3 3z"/></svg>
                Take Photo`;
            this.captureBtn.removeEventListener('click', () => this.handleCamera());
            this.captureBtn.addEventListener('click', () => this.takePhoto());

        } catch (error) {
            console.error("Error accessing camera:", error);
            alert("Could not access the camera. Please ensure you have given permission and are not using it in another application.");
        }
    }

    takePhoto() {
        const context = this.canvas.getContext('2d');
        this.canvas.width = this.video.videoWidth;
        this.canvas.height = this.video.videoHeight;
        context.drawImage(this.video, 0, 0, this.video.videoWidth, this.video.videoHeight);
        
        this.imageData = this.canvas.toDataURL('image/jpeg');
        this.imagePreview.src = this.imageData;
        
        this.showImagePreview();
        this.stopCameraStream();
        this.analyzeBtn.disabled = false;
        
        // Reset capture button
        this.captureBtn.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 12c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm0-10c-4.42 0-8 3.58-8 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z" opacity=".3"/><path d="M12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8-8-3.58 8-8 8zm0-14c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6 6-2.69 6-6 6z"/><path d="M12 14c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z"/></svg>
            Use Camera`;
        this.captureBtn.removeEventListener('click', () => this.takePhoto());
        this.captureBtn.addEventListener('click', () => this.handleCamera());
    }
    
    handleFileUpload(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                this.imageData = e.target.result;
                this.imagePreview.src = this.imageData;
                this.showImagePreview();
                this.analyzeBtn.disabled = false;
            };
            reader.readAsDataURL(file);
        }
    }

    showImagePreview() {
        this.video.classList.add('hidden');
        this.imagePreview.classList.remove('hidden');
        this.uploadPlaceholder.classList.add('hidden');
    }

    stopCameraStream() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.video.srcObject = null;
            this.stream = null;
        }
    }

    async analyzeImage() {
        if (!this.imageData) {
            alert("Please capture or upload an image first.");
            return;
        }
        
        this.showLoader(true);
        this.resultContainer.innerHTML = '<p class="placeholder-text">Interpreting the cards, please wait...</p>';

        try {
            const imagePart = {
                inlineData: {
                    data: this.imageData.split(',')[1],
                    mimeType: 'image/jpeg'
                }
            };

            const textPart = {
                text: "You are a world-class Tarot reader. Analyze the provided image of a tarot card or spread. Identify each card and provide a detailed, insightful, and empathetic interpretation based on traditional tarot meanings, symbolism, and the card's position if it's in a spread. Format the output clearly with headings for each card and then a summary of the reading."
            };

            const response = await this.ai.models.generateContent({
                model: this.model,
                contents: { parts: [imagePart, textPart] },
            });
            
            const resultText = response.text;
            this.displayResult(resultText);

        } catch (error) {
            console.error("Error during analysis:", error);
            this.displayResult("Sorry, an error occurred while analyzing the image. Please try again.");
        } finally {
            this.showLoader(false);
            this.showResetButton();
        }
    }

    displayResult(text) {
        // Simple text formatting for readability
        this.resultContainer.innerHTML = `<div class="result-content">${text.replace(/\n/g, '<br>')}</div>`;
    }

    showLoader(show) {
        if (show) {
            this.loader.classList.remove('hidden');
            this.analyzeBtn.disabled = true;
            this.analyzeBtn.querySelector('svg').classList.add('hidden');
            this.analyzeBtn.insertAdjacentHTML('afterbegin', '<span>Analyzing...</span>');
        } else {
            this.loader.classList.add('hidden');
            this.analyzeBtn.disabled = false;
            this.analyzeBtn.querySelector('span').remove();
            this.analyzeBtn.querySelector('svg').classList.remove('hidden');
        }
    }
    
    showResetButton() {
        this.captureBtn.classList.add('hidden');
        this.uploadBtn.classList.add('hidden');
        this.analyzeBtn.classList.add('hidden');
        this.resetBtn.classList.remove('hidden');
    }

    reset() {
        this.imageData = null;
        this.stopCameraStream();

        this.video.classList.add('hidden');
        this.imagePreview.classList.add('hidden');
        this.imagePreview.src = '';
        this.uploadPlaceholder.classList.remove('hidden');
        
        this.resultContainer.innerHTML = '<p class="placeholder-text">Your tarot reading will appear here...</p>';
        this.uploadInput.value = '';

        this.captureBtn.classList.remove('hidden');
        this.uploadBtn.classList.remove('hidden');
        this.analyzeBtn.classList.remove('hidden');
        this.analyzeBtn.disabled = true;
        this.resetBtn.classList.add('hidden');
    }
}

// Initialize the app
new TarotVisionAI();
