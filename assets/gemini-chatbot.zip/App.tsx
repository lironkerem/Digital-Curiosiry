
import React from 'react';
import ChatWindow from './components/ChatWindow';

const App: React.FC = () => {
  return (
    <div className="bg-slate-900 min-h-screen flex flex-col items-center justify-center text-white font-sans p-4">
        <header className="w-full max-w-4xl mx-auto text-center mb-6">
            <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                Gemini Chatbot
            </h1>
            <p className="text-slate-400 mt-2">
                Ask anything and get instant, streaming responses from Gemini 2.5 Flash.
            </p>
        </header>
        <ChatWindow />
        <footer className="w-full max-w-4xl mx-auto text-center mt-6 text-slate-500 text-sm">
            <p>Powered by Google Gemini</p>
        </footer>
    </div>
  );
};

export default App;
