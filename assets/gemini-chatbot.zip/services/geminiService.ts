
import { GoogleGenAI, Chat } from '@google/genai';
import { MODEL_NAME } from '../constants';

// NOTE: We are creating a new instance every time to ensure the latest API key is used
// if it's managed externally (e.g., via a selection dialog).
// In a typical client-side app, you might initialize this once.
const getAiClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("API_KEY environment variable not set");
    }
    return new GoogleGenAI({ apiKey });
}

export const createChatSession = (): Chat => {
  const ai = getAiClient();
  const chat: Chat = ai.chats.create({
    model: MODEL_NAME,
    config: {
      systemInstruction: 'You are a friendly and helpful assistant. Your responses should be informative and concise. Format your answers in markdown where appropriate.',
    },
  });
  return chat;
};
