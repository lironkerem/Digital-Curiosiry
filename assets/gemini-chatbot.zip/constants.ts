
export const MODEL_NAME = 'gemini-2.5-flash';
