
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Chat } from '@google/genai';
import { Message, Sender } from '../types';
import { createChatSession } from '../services/geminiService';
import ChatMessage from './Message';
import UserInput from './UserInput';

const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
      { id: 'initial-bot-message', text: 'Hello! How can I help you today?', sender: Sender.BOT }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatSessionRef.current = createChatSession();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!chatSessionRef.current || isLoading) return;

    setIsLoading(true);
    const userMessage: Message = { id: Date.now().toString(), text, sender: Sender.USER };
    
    // Create a unique ID for the bot's response message
    const botMessageId = (Date.now() + 1).toString();
    const initialBotMessage: Message = { id: botMessageId, text: '...', sender: Sender.BOT };
    
    setMessages(prev => [...prev, userMessage, initialBotMessage]);

    try {
        const stream = await chatSessionRef.current.sendMessageStream({ message: text });
        
        let accumulatedText = '';
        for await (const chunk of stream) {
            accumulatedText += chunk.text;
            setMessages(prev => 
                prev.map(msg => 
                    msg.id === botMessageId ? { ...msg, text: accumulatedText } : msg
                )
            );
        }
    } catch (error) {
        console.error("Error sending message:", error);
        const errorMessage: Message = {
            id: botMessageId,
            text: 'Sorry, something went wrong. Please try again.',
            sender: Sender.BOT
        };
        setMessages(prev => 
            prev.map(msg => 
                msg.id === botMessageId ? errorMessage : msg
            )
        );
    } finally {
        setIsLoading(false);
    }
  }, [isLoading]);

  return (
    <div className="w-full max-w-4xl h-[80vh] flex flex-col bg-slate-800 rounded-2xl shadow-2xl overflow-hidden border border-slate-700">
      <div className="flex-grow p-6 overflow-y-auto">
        {messages.map((msg) => (
          <ChatMessage key={msg.id} message={msg} />
        ))}
        <div ref={messagesEndRef} />
      </div>
      <UserInput onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default ChatWindow;
