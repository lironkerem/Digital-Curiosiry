
import React, { useRef, KeyboardEvent } from 'react';
import { SendIcon } from './Icons';

interface UserInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

const UserInput: React.FC<UserInputProps> = ({ onSendMessage, isLoading }) => {
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e?: React.FormEvent<HTMLFormElement>) => {
    e?.preventDefault();
    const message = inputRef.current?.value.trim();
    if (message && !isLoading) {
      onSendMessage(message);
      if (inputRef.current) {
        inputRef.current.value = '';
        inputRef.current.style.height = 'auto'; // Reset height
      }
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInput = (e: React.FormEvent<HTMLTextAreaElement>) => {
    const target = e.currentTarget;
    target.style.height = 'auto';
    target.style.height = `${target.scrollHeight}px`;
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-start gap-2 p-2 bg-slate-800 border-t border-slate-700"
    >
      <textarea
        ref={inputRef}
        rows={1}
        placeholder="Type your message..."
        onKeyDown={handleKeyDown}
        onInput={handleInput}
        disabled={isLoading}
        className="flex-grow bg-slate-700 text-slate-200 placeholder-slate-400 rounded-lg p-3 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50 max-h-48"
      />
      <button
        type="submit"
        disabled={isLoading}
        className="bg-purple-600 text-white rounded-lg p-3 h-12 w-12 flex-shrink-0 flex items-center justify-center hover:bg-purple-700 disabled:bg-purple-800 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-slate-900"
        aria-label="Send message"
      >
        {isLoading ? (
          <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
        ) : (
          <SendIcon className="w-6 h-6" />
        )}
      </button>
    </form>
  );
};

export default UserInput;
