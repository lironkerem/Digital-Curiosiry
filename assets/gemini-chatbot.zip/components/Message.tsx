
import React from 'react';
import { Message, Sender } from '../types';
import { UserIcon, BotIcon } from './Icons';

interface MessageProps {
  message: Message;
}

const ChatMessage: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.sender === Sender.USER;

  const containerClasses = `flex items-start gap-3 my-4 ${isUser ? 'flex-row-reverse' : ''}`;
  const bubbleClasses = `max-w-xl p-4 rounded-2xl ${isUser ? 'bg-purple-600 text-white rounded-br-none' : 'bg-slate-700 text-slate-200 rounded-bl-none'}`;
  const avatarClasses = `w-8 h-8 rounded-full flex-shrink-0 mt-1 ${isUser ? 'text-purple-300' : 'text-cyan-300'}`;

  return (
    <div className={containerClasses}>
      <div className={avatarClasses}>
        {isUser ? <UserIcon /> : <BotIcon />}
      </div>
      <div className={bubbleClasses}>
        <div className="prose prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: message.text.replace(/\n/g, '<br />') }} />
      </div>
    </div>
  );
};

export default ChatMessage;
